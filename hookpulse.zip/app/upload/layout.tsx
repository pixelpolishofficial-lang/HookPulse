import type React from "react"
export default function UploadLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
