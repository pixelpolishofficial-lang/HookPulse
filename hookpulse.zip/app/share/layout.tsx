import type React from "react"
export default function ShareLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
